// @ts-check
 
/** @type {import('next').NextConfig} */
const nextConfig = {
  /* config options here */
  trailingSlash: true, // or false, depending on your preference
}
 
module.exports = nextConfig